import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    private final List<Item> items;

    public ShoppingCart() {
        this.items = new ArrayList<>();
    }

    public void addItem(String name, double price) {
        items.add(new Item(name, price));
    }

    public void checkout(Connection connection) {
        double total = items.stream().mapToDouble(Item::getPrice).sum();
        saveReceiptToDatabase(connection, total);
        items.clear();
        System.out.println("Checkout complete. Total: $" + total);
    }

    public String generateReceiptSummary() {
        StringBuilder receipt = new StringBuilder("Receipt Summary:\n");
        items.forEach(item -> receipt.append(item.toString()).append("\n"));
        double total = items.stream().mapToDouble(Item::getPrice).sum();
        receipt.append("\nTotal: $").append(String.format("%.2f", total));
        return receipt.toString();
    }

    private void saveReceiptToDatabase(Connection connection, double total) {
        String insertReceiptQuery = "INSERT INTO receipts (total_amount) VALUES (?)";
        String insertItemsQuery = "INSERT INTO receipt_items (receipt_id, item_name, item_price) VALUES (?, ?, ?)";

        try (PreparedStatement receiptStmt = connection.prepareStatement(insertReceiptQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {
            // Save the receipt
            receiptStmt.setDouble(1, total);
            receiptStmt.executeUpdate();

            // Retrieve the generated receipt ID
            int receiptId;
            try (var generatedKeys = receiptStmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    receiptId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating receipt failed, no ID obtained.");
                }
            }

            // Save each item associated with the receipt
            try (PreparedStatement itemsStmt = connection.prepareStatement(insertItemsQuery)) {
                for (Item item : items) {
                    itemsStmt.setInt(1, receiptId);
                    itemsStmt.setString(2, item.getName());
                    itemsStmt.setDouble(3, item.getPrice());
                    itemsStmt.addBatch();
                }
                itemsStmt.executeBatch();
            }

        } catch (SQLException e) {
            System.err.println("Error saving receipt to database: " + e.getMessage());
        }
    }

    private static class Item {
        private final String name;
        private final double price;

        public Item(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        @Override
        public String toString() {
            return name + " - $" + String.format("%.2f", price);}}
}