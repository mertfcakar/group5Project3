import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CashierGUI {

    private static Stage primaryStage;
    private static Connection connection;
    private static Map<String, String> movieDatabase;
    private static ShoppingCart shoppingCart;

    public static void display(Stage stage, String username) {
        primaryStage = stage;
        movieDatabase = new HashMap<>();
        shoppingCart = new ShoppingCart();

        // Establish database connection using DatabaseFacade
        try {
            AuthenticationManager dbFacade = new AuthenticationManager();
            connection = dbFacade.connect();
            loadMovieDatabase();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not connect to database: " + e.getMessage());
            return;
        }

        showSearchInterface();
    }

    private static void loadMovieDatabase() throws SQLException {
        String query = "SELECT title, summary_path FROM movies";
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String title = rs.getString("title");
                String summary = rs.getString("summary_path");
                movieDatabase.put(title, summary);
            }
        }
    }

    private static void showSearchInterface() {
        primaryStage.setTitle("Cashier Operations - Search Movies");

        Label searchLabel = new Label("Search for a Movie:");
        TextField searchField = new TextField();
        Button searchButton = new Button("Search");

        ListView<String> resultsList = new ListView<>();
        searchButton.setOnAction(e -> {
            String searchTerm = searchField.getText().toLowerCase();
            resultsList.getItems().clear();
            for (String movie : movieDatabase.keySet()) {
                if (movie.toLowerCase().contains(searchTerm)) {
                    resultsList.getItems().add(movie);
                }
            }
        });

        Button confirmButton = new Button("Confirm");
        confirmButton.setOnAction(e -> {
            String selectedMovie = resultsList.getSelectionModel().getSelectedItem();
            if (selectedMovie == null) {
                showAlert(Alert.AlertType.ERROR, "Selection Error", "Please select a movie.");
            } else {
                showMovieDetails(selectedMovie);
            }
        });

        VBox layout = new VBox(10, searchLabel, searchField, searchButton, resultsList, confirmButton);
        primaryStage.setScene(new Scene(layout, 400, 300));
        primaryStage.show();
    }

    private static void showMovieDetails(String movie) {
        Label movieDetails = new Label(movieDatabase.get(movie));
        ImageView poster = new ImageView(); // Placeholder for movie poster if needed

        Button confirmButton = new Button("Approve");
        confirmButton.setOnAction(e -> showDaySessionSelection(movie));

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showSearchInterface());

        VBox layout = new VBox(10, movieDetails, poster, confirmButton, backButton);
        primaryStage.setScene(new Scene(layout, 400, 300));
    }

    private static void showDaySessionSelection(String movie) {
        Label movieLabel = new Label("Movie: " + movie);
        Label dayLabel = new Label("Select Day:");
        ComboBox<String> dayComboBox = new ComboBox<>();
        dayComboBox.getItems().addAll("2025-01-13", "2025-01-14", "2025-01-15", "2025-01-16", "2025-01-17", "2025-01-18", "2025-01-19");

        Label sessionLabel = new Label("Select Session:");
        ComboBox<String> sessionComboBox = new ComboBox<>();
        try {
            String query = "SELECT start_time FROM sessions";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                sessionComboBox.getItems().add(rs.getString("start_time"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not load session times: " + e.getMessage());
        }

        Label hallLabel = new Label("Select Hall:");
        ComboBox<String> hallComboBox = new ComboBox<>();
        try {
            String query = "SELECT name FROM halls";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                hallComboBox.getItems().add(rs.getString("name"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not load halls: " + e.getMessage());
        }

        Button confirmButton = new Button("Confirm");
        confirmButton.setOnAction(e -> {
            String day = dayComboBox.getValue();
            String session = sessionComboBox.getValue();
            String hall = hallComboBox.getValue();

            if (day == null || session == null || hall == null) {
                showAlert(Alert.AlertType.ERROR, "Selection Error", "Please make all selections.");
            } else {
                showSeatSelection(movie, day, session, hall);
            }
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showMovieDetails(movie));

        VBox layout = new VBox(10, movieLabel, dayLabel, dayComboBox, sessionLabel, sessionComboBox, hallLabel, hallComboBox, confirmButton, backButton);
        primaryStage.setScene(new Scene(layout, 400, 400));
    }

    private static void showSeatSelection(String movie, String day, String session, String hall) {
        Label seatLabel = new Label("Select Seats:");
        ListView<String> seatList = new ListView<>();
        loadAvailableSeats(seatList, hall, day);

        Button addSeatButton = new Button("Add to Cart");
        addSeatButton.setOnAction(e -> {
            String seat = seatList.getSelectionModel().getSelectedItem();
            if (seat != null) {
                shoppingCart.addItem("Seat: " + seat, 50.0);
                showAlert(Alert.AlertType.INFORMATION, "Seat Added", "Seat " + seat + " added to cart.");
                seatList.getItems().remove(seat);
            } else {
                showAlert(Alert.AlertType.ERROR, "Selection Error", "Please select a seat.");
            }
        });

        Button proceedButton = new Button("Proceed to Products");
        proceedButton.setOnAction(e -> showProductSelection());

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showDaySessionSelection(movie));

        VBox layout = new VBox(10, seatLabel, seatList, addSeatButton, proceedButton, backButton);
        primaryStage.setScene(new Scene(layout, 400, 400));
    }

    private static void showProductSelection() {
        Label productLabel = new Label("Select Additional Products:");
        ListView<String> productList = new ListView<>();
        loadProducts(productList);

        Button addProductButton = new Button("Add to Cart");
        addProductButton.setOnAction(e -> {
            String product = productList.getSelectionModel().getSelectedItem();
            if (product != null) {
                String[] parts = product.split(" - \\$");
                if (parts.length == 2) {
                    String productName = parts[0];
                    double price = Double.parseDouble(parts[1]);
                    shoppingCart.addItem(productName, price);
                    showAlert(Alert.AlertType.INFORMATION, "Product Added", productName + " added to cart.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Parsing Error", "Could not parse selected product.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Selection Error", "Please select a product.");
            }
        });

        Button checkoutButton = new Button("Checkout");
        checkoutButton.setOnAction(e -> {
            shoppingCart.checkout(connection);
            showAlert(Alert.AlertType.INFORMATION, "Checkout Complete", "Thank you for your purchase!\n\n" +
                    shoppingCart.generateReceiptSummary());
            showSearchInterface();
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showSeatSelection(null, null, null, null));

        VBox layout = new VBox(10, productLabel, productList, addProductButton, checkoutButton, backButton);
        primaryStage.setScene(new Scene(layout, 400, 400));
    }

    private static void loadAvailableSeats(ListView<String> seatList, String hall, String day) {
        try {
            String query = "SELECT seat_number FROM available_seats WHERE hall_id = ? AND schedule_date = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, getHallId(hall));
            stmt.setDate(2, java.sql.Date.valueOf(day));
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                seatList.getItems().add(rs.getString("seat_number"));
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not load seats: " + e.getMessage());
        }
    }

    private static void loadProducts(ListView<String> productList) {
        try {
            String query = "SELECT name, price FROM products";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String product = rs.getString("name") + " - $" + rs.getDouble("price");
                productList.getItems().add(product);
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not load products: " + e.getMessage());
        }
    }

    private static int getHallId(String hall) throws SQLException {
        String query = "SELECT hall_id FROM halls WHERE name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, hall);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("hall_id");
            }
        }
        throw new SQLException("Hall not found.");
    }

    private static void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}