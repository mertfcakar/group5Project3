import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class AdminGUI {
    private static AuthenticationManager dbFacade = new AuthenticationManager();

    public static void display(Stage stage, String username) {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Label welcomeLabel = new Label("Admin Dashboard\nWelcome, " + username);
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button addMovieButton = new Button("Add New Movie");
        Button updateMovieButton = new Button("Update Existing Movie");
        Button scheduleButton = new Button("Create Monthly Schedule");
        Button cancellationButton = new Button("Process Cancellations");
        Button logoutButton = new Button("Logout");

        addMovieButton.setOnAction(e -> showAddMovieDialog());
        updateMovieButton.setOnAction(e -> showUpdateMovieDialog());
        scheduleButton.setOnAction(e -> showScheduleDialog());
        cancellationButton.setOnAction(e -> showCancellationDialog(username));
        logoutButton.setOnAction(e -> {
            Main mainApp = new Main();
            mainApp.start(stage);
        });

        layout.getChildren().addAll(welcomeLabel, addMovieButton, updateMovieButton,
                scheduleButton, cancellationButton, logoutButton);

        Scene scene = new Scene(layout, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Admin Dashboard");
        stage.show();
    }

    private static void showAddMovieDialog() {
        Stage dialog = new Stage();
        dialog.setTitle("Add New Movie");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField titleField = new TextField();
        titleField.setPromptText("Movie Title");
        TextField genreField = new TextField();
        genreField.setPromptText("Genre");
        TextArea summaryArea = new TextArea();
        summaryArea.setPromptText("Summary");

        Button selectPosterButton = new Button("Select Poster");
        ImageView posterPreview = new ImageView();
        posterPreview.setFitWidth(100);
        posterPreview.setFitHeight(150);

        final File[] posterFile = new File[1];
        selectPosterButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Image Files", ".png", ".jpg", "*.jpeg")
            );
            File selectedFile = fileChooser.showOpenDialog(dialog);
            if (selectedFile != null) {
                posterFile[0] = selectedFile;
                posterPreview.setImage(new Image(selectedFile.toURI().toString()));
            }
        });

        Button addButton = new Button("Add Movie");
        addButton.setOnAction(e -> {
            String title = titleField.getText();
            String genre = genreField.getText();
            String summary = summaryArea.getText();

            if (title.isEmpty() || posterFile[0] == null || genre.isEmpty() || summary.isEmpty()) {
                showAlert("Error", "All fields must be filled.");
                return;
            }

            try (Connection conn = dbFacade.connect()) {
                String query = "INSERT INTO movies (title, poster_path, genre, summary) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, title);
                stmt.setString(2, posterFile[0].getPath());
                stmt.setString(3, genre);
                stmt.setString(4, summary);
                stmt.executeUpdate();
                showAlert("Success", "Movie added successfully!");
                dialog.close();
            } catch (SQLException ex) {
                showAlert("Error", "Failed to add movie: " + ex.getMessage());
            }
        });

        grid.addRow(0, new Label("Title:"), titleField);
        grid.addRow(1, new Label("Genre:"), genreField);
        grid.addRow(2, new Label("Summary:"), summaryArea);
        grid.addRow(3, new Label("Poster:"), selectPosterButton, posterPreview);
        grid.add(addButton, 1, 4);

        Scene scene = new Scene(grid, 400, 400);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void showUpdateMovieDialog() {
        Stage dialog = new Stage();
        dialog.setTitle("Update Existing Movie");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        ComboBox<String> movieComboBox = new ComboBox<>();
        TextField genreField = new TextField();
        genreField.setPromptText("New Genre");
        TextArea summaryArea = new TextArea();
        summaryArea.setPromptText("New Summary");

        Button selectPosterButton = new Button("Select New Poster");
        ImageView posterPreview = new ImageView();
        posterPreview.setFitWidth(100);
        posterPreview.setFitHeight(150);

        final File[] posterFile = new File[1];
        selectPosterButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Image Files", ".png", ".jpg", "*.jpeg")
            );
            File selectedFile = fileChooser.showOpenDialog(dialog);
            if (selectedFile != null) {
                posterFile[0] = selectedFile;
                posterPreview.setImage(new Image(selectedFile.toURI().toString()));
            }
        });

        Button updateButton = new Button("Update Movie");

        try (Connection conn = dbFacade.connect()) {
            String query = "SELECT title FROM movies";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                movieComboBox.getItems().add(rs.getString("title"));
            }
        } catch (SQLException ex) {
            showAlert("Error", "Failed to load movies: " + ex.getMessage());
        }

        updateButton.setOnAction(e -> {
            String selectedMovie = movieComboBox.getValue();
            String newGenre = genreField.getText();
            String newSummary = summaryArea.getText();

            if (selectedMovie == null || posterFile[0] == null || newGenre.isEmpty() || newSummary.isEmpty()) {
                showAlert("Error", "All fields must be filled.");
                return;
            }

            try (Connection conn = dbFacade.connect()) {
                String query = "UPDATE movies SET poster_path = ?, genre = ?, summary = ? WHERE title = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, posterFile[0].getPath());
                stmt.setString(2, newGenre);
                stmt.setString(3, newSummary);
                stmt.setString(4, selectedMovie);
                stmt.executeUpdate();
                showAlert("Success", "Movie updated successfully!");
                dialog.close();
            } catch (SQLException ex) {
                showAlert("Error", "Failed to update movie: " + ex.getMessage());
            }
        });

        grid.addRow(0, new Label("Select Movie:"), movieComboBox);
        grid.addRow(1, new Label("New Genre:"), genreField);
        grid.addRow(2, new Label("New Summary:"), summaryArea);
        grid.addRow(3, new Label("New Poster:"), selectPosterButton, posterPreview);
        grid.add(updateButton, 1, 4);

        Scene scene = new Scene(grid, 400, 400);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void showScheduleDialog() {
        // Implementation here (omitted for brevity but similar logic as above dialogs)
    }

    private static void showCancellationDialog(String username) {
        // Implementation here (omitted for brevity but similar logic as above dialogs)
    }

    private static void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();}
}