package src;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class MainController {

    @FXML
    private TextField userTextField;

    @FXML
    private PasswordField pwBox;

    @FXML
    private Button loginButton;

    @FXML
    private Label messageLogin;

    @FXML
    public void initialize() {
        loginButton.setOnAction(e -> handleLoginButtonAction());
    }

    @FXML
    private void handleLoginButtonAction() {
        String username = userTextField.getText();
        String password = pwBox.getText();

        // Veritabanı üzerinden giriş kontrolü
        String role = AuthenticationManager.authenticate(username, password);

        if (role != null) {
            messageLogin.setText("Login successful! Role: " + role);
        } else {
            messageLogin.setText("Invalid credentials. Please try again.");
        }
    }
}
