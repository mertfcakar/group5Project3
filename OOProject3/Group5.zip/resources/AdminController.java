import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class AdminController {

    // Movies Management Sekmesi Bileşenleri
    @FXML
    private TextField movieTitleField;
    @FXML
    private TextField movieGenreField;
    @FXML
    private TextArea movieSummaryField;
    @FXML
    private Button addMovieButton;
    @FXML
    private Button updateMovieButton;
    @FXML
    private TableView<?> moviesTable;

    // Schedule Management Sekmesi Bileşenleri
    @FXML
    private ComboBox<?> movieSelector;
    @FXML
    private DatePicker datePicker;
    @FXML
    private ComboBox<?> hallSelector;
    @FXML
    private Button addScheduleButton;
    @FXML
    private TableView<?> scheduleTable;

    // Refunds Sekmesi Bileşenleri
    @FXML
    private TableView<?> refundsTable;
    @FXML
    private Button processRefundButton;

    // Buton İşlevleri
    @FXML
    private void handleAddMovie() {
        System.out.println("Add Movie Clicked
